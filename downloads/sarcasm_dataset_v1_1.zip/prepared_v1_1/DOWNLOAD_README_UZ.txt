YUKLAB OLINGAN DATASET V1.1

CSV va Excel fayllari tayyor: ularni to‘g‘ridan-to‘g‘ri ochish mumkin.
SQLite reyestri registry.sqlite.xz ichida qo‘shimcha siqilgan.
Uni ochish uchun shu katalogda Python buyrug‘ini bajaring:

python -c "import lzma,shutil; s=lzma.open('registry.sqlite.xz','rb'); d=open('registry.sqlite','wb'); shutil.copyfileobj(s,d); s.close(); d.close()"

registry_restore.json ochilgan bazaning SHA256 hashini beradi.
checksums.json arxiv ichidagi fayllarni tekshiradi.
checksums_original_uncompressed.json tayyorlash bosqichidagi asl manifestdir.

Bu dastlabki yorliqlari saqlangan tayyorlash korpusi, inson-gold test emas.
